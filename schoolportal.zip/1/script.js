const STORAGE_KEY = 'studentGradeManager_v2';
const TEACHER_KEY = 'studentGradeTeacher_v1';

let students = loadStudents();
let currentUser = null;

function loadTeacherAccount() {
    try {
        const saved = JSON.parse(localStorage.getItem(TEACHER_KEY));

        return saved || {
            username: 'teacher',
            password: 'teacher123'
        };
    } catch (e) {
        return {
            username: 'teacher',
            password: 'teacher123'
        };
    }
}

let teacherAccount = loadTeacherAccount();

function saveTeacherAccount() {
    localStorage.setItem(TEACHER_KEY, JSON.stringify(teacherAccount));
}

function loadStudents() {
    try {
        return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    } catch (e) {
        return [];
    }
}

function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
    renderTeacher();
}

function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    }[c]));
}

function average(s) {
    return s.grades.length
        ? s.grades.reduce((a, g) => a + Number(g.score), 0) / s.grades.length
        : 0;
}

function isPassed(grade) {
    return Number(grade) >= 75;
}

function show(view) {

    ['loginView', 'teacherView', 'studentView'].forEach(id => {
        document.getElementById(id).classList.toggle('hidden', id !== view);
    });

    document.getElementById('logoutBtn').classList.toggle(
        'hidden',
        view === 'loginView'
    );

    const settingsBtn = document.getElementById('teacherSettingsBtn');

    if (settingsBtn) {
        settingsBtn.classList.toggle(
            'hidden',
            view !== 'teacherView'
        );
    }

    document.getElementById('welcome').textContent = currentUser
        ? (currentUser.role === 'teacher'
            ? 'Teacher Portal'
            : 'Student Portal · ' + currentUser.name)
        : '';
}

function openTeacherSettings() {
    if (!currentUser || currentUser.role !== 'teacher') {
        return;
    }

    sessionStorage.setItem('sgmsTeacherLoggedIn', 'true');
    window.location.href = 'teacher-settings.html';
}

document.getElementById('loginForm').addEventListener('submit', e => {
    e.preventDefault();

    const role = document.getElementById('role').value;
    const id = document.getElementById('loginId').value.trim();
    const pw = document.getElementById('loginPassword').value;
    const msg = document.getElementById('loginMessage');

    if (role === 'teacher') {

        if (
            id === teacherAccount.username &&
            pw === teacherAccount.password
        ) {
            currentUser = { role: 'teacher' };
            sessionStorage.setItem('sgmsTeacherLoggedIn', 'true');

            show('teacherView');
            renderTeacher();

            msg.textContent = '';
        } else {
            msg.textContent = 'Incorrect teacher username or password.';
        }

    } else {

        const s = students.find(x =>
            x.number.toLowerCase() === id.toLowerCase() &&
            x.password === pw
        );

        if (s) {
            currentUser = {
                role: 'student',
                id: s.id,
                name: s.name
            };

            show('studentView');
            renderStudent(s);

            msg.textContent = '';

        } else {
            msg.textContent =
                'Student ID or password is incorrect. Ask your teacher to create your account.';
        }
    }
});

const teacherSettingsForm = document.getElementById('teacherSettingsForm');

if (teacherSettingsForm) {

    teacherSettingsForm.addEventListener('submit', e => {
        e.preventDefault();

        if (!currentUser || currentUser.role !== 'teacher') return;

        const currentPassword =
            document.getElementById('currentTeacherPassword').value;

        const newUsername =
            document.getElementById('newTeacherUsername').value.trim();

        const newPassword =
            document.getElementById('newTeacherPassword').value;

        const confirmPassword =
            document.getElementById('confirmTeacherPassword').value;

        const msg =
            document.getElementById('teacherSettingsMessage');

        if (currentPassword !== teacherAccount.password) {
            msg.textContent = 'Incorrect current password.';
            return;
        }

        if (!newUsername || !newPassword) {
            msg.textContent = 'Username and password cannot be empty.';
            return;
        }

        if (newPassword.length < 5) {
            msg.textContent = 'Password must contain at least 5 characters.';
            return;
        }

        if (newPassword !== confirmPassword) {
            msg.textContent = 'New passwords do not match.';
            return;
        }

        teacherAccount = {
            username: newUsername,
            password: newPassword
        };

        saveTeacherAccount();

        teacherSettingsForm.reset();

        msg.textContent =
            'Teacher username and password updated successfully!';
    });

}

function logout() {
    currentUser = null;
    sessionStorage.removeItem('sgmsTeacherLoggedIn');

    document.getElementById('loginForm').reset();
    document.getElementById('loginMessage').textContent = '';

    show('loginView');
}

function addGradeRow(subject = '', score = '') {
    const row = document.createElement('div');

    row.className = 'grade-row';

    row.innerHTML = `
        <input
            class="subject"
            aria-label="Subject name"
            placeholder="Subject"
            maxlength="60"
            value="${esc(subject)}"
        >

        <input
            class="score"
            aria-label="Grade"
            type="number"
            min="0"
            max="100"
            step="0.01"
            placeholder="Grade"
            value="${esc(score)}"
        >

        <button
            type="button"
            aria-label="Remove subject"
            title="Remove subject"
            onclick="this.parentElement.remove()"
        >×</button>
    `;

    document.getElementById('gradeList').appendChild(row);
}

function readGrades() {
    return [...document.querySelectorAll('.grade-row')]
        .map(r => ({
            subject: r.querySelector('.subject').value.trim(),

            score: r.querySelector('.score').value.trim() === ''
                ? null
                : Number(r.querySelector('.score').value)
        }))
        .filter(g => g.subject !== '' || g.score !== null);
}

function resetForm() {
    document.getElementById('studentForm').reset();

    document.getElementById('studentId').value = '';
    document.getElementById('gradeList').innerHTML = '';

    addGradeRow();
    addGradeRow();

    document.getElementById('formTitle').textContent = 'Add Student';
    document.getElementById('saveButton').textContent = 'Save Student';

    document.getElementById('message').textContent = '';
}

document.getElementById('studentForm').addEventListener('submit', e => {
    e.preventDefault();

    if (!currentUser || currentUser.role !== 'teacher') return;

    const id = document.getElementById('studentId').value;

    const name = document.getElementById('studentName').value.trim();
    const number = document.getElementById('studentNumber').value.trim();
    const course = document.getElementById('studentCourse').value.trim();
    const password = document.getElementById('studentPassword').value;

    const grades = readGrades();
    const msg = document.getElementById('message');

    if (grades.some(g =>
        !g.subject ||
        !Number.isFinite(g.score) ||
        g.score < 0 ||
        g.score > 100
    )) {
        msg.textContent =
            'Check subject names and grades. Grades must be 0–100.';
        return;
    }

    if (new Set(grades.map(g => g.subject.toLowerCase())).size !== grades.length) {
        msg.textContent = 'Subject names must be unique.';
        return;
    }

    if (students.some(s =>
        s.number.toLowerCase() === number.toLowerCase() &&
        s.id !== id
    )) {
        msg.textContent = 'That Student ID already exists.';
        return;
    }

    const record = {
        id: id || String(Date.now()),
        name,
        number,
        course,
        password,
        grades
    };

    if (id) {
        students = students.map(s => s.id === id ? record : s);
    } else {
        students.push(record);
    }

    persist();
    resetForm();

    alert(id
        ? 'Student record updated successfully!'
        : 'Student account created successfully! Grades can be added later.'
    );
});

function editStudent(id) {
    if (!currentUser || currentUser.role !== 'teacher') return;

    const s = students.find(x => x.id === id);

    if (!s) return;

    document.getElementById('studentId').value = s.id;
    document.getElementById('studentName').value = s.name;
    document.getElementById('studentNumber').value = s.number;
    document.getElementById('studentCourse').value = s.course;
    document.getElementById('studentPassword').value = s.password;

    document.getElementById('gradeList').innerHTML = '';

    s.grades.forEach(g => addGradeRow(g.subject, g.score));

    if (s.grades.length === 0) {
        addGradeRow();
        addGradeRow();
    }

    document.getElementById('formTitle').textContent = 'Edit Student';
    document.getElementById('saveButton').textContent = 'Update Student';

    document.getElementById('message').textContent =
        'Editing ' + s.name;

    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

function deleteStudent(id) {
    if (!currentUser || currentUser.role !== 'teacher') return;

    const s = students.find(x => x.id === id);

    if (s && confirm(`Delete ${s.name}'s record and portal account?`)) {

        students = students.filter(x => x.id !== id);

        persist();

        if (document.getElementById('studentId').value === id) {
            resetForm();
        }
    }
}


function renderTeacher() {
    if (!currentUser || currentUser.role !== 'teacher') return;

    const q = document.getElementById('searchInput').value.toLowerCase();
    const filter = document.getElementById('filterSelect').value;

    const visible = students.filter(s =>
        (s.name + ' ' + s.number + ' ' + s.course)
            .toLowerCase().includes(q) &&
        (
            filter === 'all' ||
            (filter === 'passed'
                ? isPassed(average(s))
                : !isPassed(average(s)))
        )
    );

    document.getElementById('studentRows').innerHTML = visible.length
        ? visible.map(s => {

            const a = average(s);
            const pass = isPassed(a);

            return `
                <tr>
                    <td>
                        <strong>${esc(s.name)}</strong><br>
                        <span class="hint">${esc(s.number)}</span>
                    </td>

                    <td>${esc(s.course || '—')}</td>

                    <td>${s.grades.length}</td>

                    <td><strong>${a.toFixed(2)}%</strong></td>

                    <td>
                        <span class="pill ${pass ? '' : 'fail'}">
                            ${pass ? 'Passed' : 'Failed'}
                        </span>
                    </td>

                    <td>
                        <div class="actions" style="margin:0">

                            <button
                                class="small secondary"
                                onclick="editStudent('${esc(s.id)}')"
                            >Edit</button>

                            <button
                                class="small danger"
                                onclick="deleteStudent('${esc(s.id)}')"
                            >Delete</button>

                        </div>
                    </td>
                </tr>
            `;
        }).join('')

        : '<tr><td colspan="6" class="empty">No student records found.</td></tr>';

    document.getElementById('totalStudents').textContent =
        students.length;

    document.getElementById('classAverage').textContent =
        students.length
            ? (
                students.reduce((n, s) => n + average(s), 0) /
                students.length
            ).toFixed(2) + '%'
            : '—';

    document.getElementById('passedCount').textContent =
        students.filter(s => isPassed(average(s))).length;

    document.getElementById('failedCount').textContent =
        students.filter(s => !isPassed(average(s))).length;
}

function renderStudent(s) {
    document.getElementById('myName').textContent = s.name;
    document.getElementById('myId').textContent = s.number;

    const a = average(s);
    const pass = isPassed(a);

    document.getElementById('myAverage').textContent =
        a.toFixed(2) + '%';

    document.getElementById('myStatus').textContent =
        pass ? 'Passed' : 'Failed';

    document.getElementById('myStatus').className =
        'pill ' + (pass ? '' : 'fail');

    document.getElementById('myGrades').innerHTML =
        s.grades.length

            ? s.grades.map(g => {

                const subjectPassed = isPassed(g.score);

                return `
                    <tr>
                        <td>${esc(g.subject)}</td>

                        <td>
                            <strong>${Number(g.score).toFixed(2)}%</strong>
                        </td>

                        <td>
                            <span class="pill ${subjectPassed ? '' : 'fail'}">
                                ${subjectPassed ? 'Passed' : 'Failed'}
                            </span>
                        </td>
                    </tr>
                `;
            }).join('')

            : `
                <tr>
                    <td colspan="3" class="empty">
                        No grades have been encoded yet.
                    </td>
                </tr>
            `;
}

function exportCSV() {
    if (!currentUser || currentUser.role !== 'teacher') return;

    if (!students.length) {
        alert('There are no records to export.');
        return;
    }

    const rows = [[
        'Student ID',
        'Full Name',
        'Course / Section',
        'Subject',
        'Grade',
        'Average',
        'Status'
    ]];

    students.forEach(s => {

        if (s.grades.length === 0) {

            rows.push([
                s.number,
                s.name,
                s.course,
                'No grades yet',
                '',
                '0.00',
                'No Grades'
            ]);

        } else {

            s.grades.forEach(g => {
                rows.push([
                    s.number,
                    s.name,
                    s.course,
                    g.subject,
                    g.score,
                    average(s).toFixed(2),
                    isPassed(average(s)) ? 'Passed' : 'Failed'
                ]);
            });
        }
    });

    const csv = rows.map(r =>
        r.map(v =>
            '"' + String(v ?? '').replace(/"/g, '""') + '"'
        ).join(',')
    ).join('\r\n');

    const blob = new Blob([csv], {
        type: 'text/csv;charset=utf-8;'
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');

    a.href = url;
    a.download = 'student-grade-records.csv';
    a.click();

    URL.revokeObjectURL(url);
}

addGradeRow();
addGradeRow();

if (sessionStorage.getItem('sgmsTeacherLoggedIn') === 'true') {
    currentUser = { role: 'teacher' };
    show('teacherView');
    renderTeacher();
} else {
    show('loginView');
}