const TEACHER_KEY = 'studentGradeTeacher_v1';
const SESSION_KEY = 'sgmsTeacherLoggedIn';

function loadTeacherAccount() {
    try {
        const saved = JSON.parse(localStorage.getItem(TEACHER_KEY));
        return saved || {
            username: 'teacher',
            password: 'teacher123'
        };
    } catch (error) {
        return {
            username: 'teacher',
            password: 'teacher123'
        };
    }
}

if (sessionStorage.getItem(SESSION_KEY) !== 'true') {
    window.location.replace('index.html');
}

const settingsForm = document.getElementById('teacherSettingsForm');

settingsForm.addEventListener('submit', function (event) {
    event.preventDefault();

    const teacherAccount = loadTeacherAccount();

    const currentPassword =
        document.getElementById('currentTeacherPassword').value;

    const newUsername =
        document.getElementById('newTeacherUsername').value.trim();

    const newPassword =
        document.getElementById('newTeacherPassword').value;

    const confirmPassword =
        document.getElementById('confirmTeacherPassword').value;

    const message =
        document.getElementById('teacherSettingsMessage');

    message.textContent = '';

    if (currentPassword !== teacherAccount.password) {
        message.textContent = 'Incorrect current password.';
        return;
    }

    if (!newUsername) {
        message.textContent = 'Username cannot be empty.';
        return;
    }

    if (newPassword.length < 6) {
        message.textContent = 'Password must contain at least 6 characters.';
        return;
    }

    if (newPassword !== confirmPassword) {
        message.textContent = 'New passwords do not match.';
        return;
    }

    const updatedAccount = {
        username: newUsername,
        password: newPassword
    };

    try {
        localStorage.setItem(TEACHER_KEY, JSON.stringify(updatedAccount));
        settingsForm.reset();
        message.textContent =
            'Teacher account updated successfully. Use your new credentials the next time you log in.';
    } catch (error) {
        message.textContent =
            'Unable to save the account. Please check your browser storage settings.';
        console.error('Could not save teacher account:', error);
    }
});

function goBack() {
    window.location.href = 'index.html';
}

function logoutTeacher() {
    sessionStorage.removeItem(SESSION_KEY);
    window.location.href = 'index.html';
}
